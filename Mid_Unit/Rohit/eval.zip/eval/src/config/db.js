const mongoose = require('mongoose');
 const connect = () => {
     //return mongoose.connect("mongodb+srv://rohith:12345@cluster0.6csmw.mongodb.net/purplle?retryWrites=true&w=majority");


 }

 module.exports = connect;